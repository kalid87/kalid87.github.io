


var nameNode = document.getElementById("name");
nameNode.addEventListener("click", function (){
    alert("Wellcom to Khalid Homepage")
});